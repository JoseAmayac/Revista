package tareacarro;

/**
 *
 * @author josea
 */
public abstract class Llanta
{

    /**
     * 
     */
    private double limitaPermitido;
    
    /**
     * 
     * @param nombre
     * @param limitaPermitido 
     */
    Llanta(double limitaPermitido)
    {
        this.limitaPermitido=limitaPermitido;
    }
  
    /**
     * 
     * @return 
     */
    public double getLimitaPermitido()
    {
        return limitaPermitido;
    }  
}
