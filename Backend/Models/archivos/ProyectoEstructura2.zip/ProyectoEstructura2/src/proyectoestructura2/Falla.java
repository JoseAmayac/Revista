/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoestructura2;

import java.util.ArrayList;

/**
 *
 * @author Administrador
 */
public class Falla 
{
    
    /**
     * 
     */
    private String tipo;
    
    /**
     * 
     */
    private ArrayList<String> sintomas;
    
    /**
     * 
     * @param tipo 
     */
    public Falla(String tipo) 
    {
        this.tipo = tipo;
        this.sintomas=new ArrayList<>();
    }
    
    /**
     * 
     * @param sintoma 
     */
    public boolean agregarSintomas(String sintoma)
    {
        if(!this.sintomas.contains(sintoma))
        {
           this.sintomas.add(sintoma);
           
           return true;
        }
        return false;
    }

    public String getTipo() {
        return tipo;
    }

    public ArrayList<String> getSintomas() 
    {
        return sintomas;
    }
    
    
    
}
