package tareacarro;

/**
 *
 * @author josea
 */
public abstract class Motor
{   
    /**
     * 
     */
    private int velocidadMaxima;
    
    /**
     * 
     * @param cilindraje
     * @param velocidadMaxima 
     */
    public Motor(int velocidadMaxima)
    {
       this.velocidadMaxima=velocidadMaxima;
    }

    public int getVelocidadMaxima()
    {
        return velocidadMaxima;
    }
}
