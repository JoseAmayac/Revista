
package tareacarro.excepcion;

/**
 *Excepcion que se lanza al momento de querer frenar y que el carro ya este frenado 
 * @author José Luciano Amaya Carrascal
 * @author Hector Fabio Martinez Gomez
 * @version 20170501
 * @since 1.0
 */
public class AutoYaFrenadoException extends Exception 
{
    
    /**
     * Constructor de objetos de la clase AutoYaFrenadoException
     * @param mensaje el mensaje mostrado cuando se genera la excepcion
     */
    public AutoYaFrenadoException(String mensaje) 
    {
        super(mensaje);
    }
}
