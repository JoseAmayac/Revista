
package tareacarro.excepcion;

/**
 *Excepcion que se lanza cuando se quiere encender el carro y este ya esté encendido
 * @author José Luciano Amaya Carrascal
 * @author Hector Fabio Martinez Gomez
 * @version 20170501
 * @since 1.0
 */
public class AutoYaEncendidoException extends Exception
{
    public AutoYaEncendidoException(String mensaje)
    {
        super(mensaje);
    } 
}
