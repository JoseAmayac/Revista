/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoestructura2;

import java.util.ArrayList;

/**
 *
 * @author Administrador
 */
public class TeoremaBayes 
{
    /**
     * 
     */
    private ArrayList<Carro> carros;
    
    /**
     * 
     */
    public TeoremaBayes()
    {
        this.carros=new ArrayList<>();
        this.generarDatos(100000);
    }
    
    /**
     * 
     * @param numeroDatos 
     */
    public void generarDatos(int numeroDatos)
    {
        String[] marca={"Mazda","Ford","Chevrolet"};

        
        for (int i = 0; i <numeroDatos; i++)
        {
            int numeroMarca= (int)(Math.random()*3);
            
            int numeroFalla= (int)(Math.random()*100);
            
            if(numeroFalla<2)
            {
               
               this.carros.add(new Carro(marca[numeroMarca],this.generarFalla()));
            }
            else
            {
               
               this.carros.add(new Carro(marca[numeroMarca]));
            }
            
            
        
        }
        
    }
    public void consulta(String marcaCarro,ArrayList<String> sintomas)
    {
        int poblacion=this.carros.size();
        
       
         int fallasMotor=0;
         int fallasSistemaElectrico=0;
         int fallasTransmision=0;
         
         ArrayList<Carro> carrosTemp=this.buscarCarros(marcaCarro);
         
         float carrosMarca=carrosTemp.size();
         
         float probMarca=carrosMarca/poblacion;
         
         System.out.println("La probabilidad de que la marca sea "+marcaCarro
                             +" es "+probMarca);
         
         float fallasMarca=0;
         
         float contCoicidencias=0;
         
         for (int j = 0; j < carrosTemp.size(); j++) 
         {
            Carro carroTemp=carrosTemp.get(j);
            if(carroTemp.isFalla())
            {
               
               fallasMarca++;
                
               Falla falla=carroTemp.getFalla();
                
                
               ArrayList<String> sintomasReales=falla.getSintomas();
               if(this.calcularCoicidencia(sintomas,sintomasReales))
               {
                  
                   contCoicidencias++;
                   
                   if(falla.getTipo().equals("Motor"))
                   {
                       
                        fallasMotor++;
                   }
                   if(falla.getTipo().equals("Sistema Electrico"))
                   {
                        fallasSistemaElectrico++;
                        
                   }
                   if(falla.getTipo().equals("Transmision"))
                   {
                        fallasTransmision++;
                        
                   }
               }
                
               
            }
         
         }
         System.out.println("La probabilidad de un carro "+marcaCarro
                             +" presente fallas es "+fallasMarca/carrosMarca);
           float probMotor=(fallasMotor/contCoicidencias)*100;
           float probSistemaE=(fallasSistemaElectrico/contCoicidencias)*100;
           float probTransmision=(fallasTransmision/contCoicidencias)*100;
           
           
           
           System.out.println("La probabilidad de que sea falla del motor es: "+probMotor);
           System.out.println("La probabilidad de que sea falla del sistema electrico es: "+probSistemaE);
           System.out.println("La probabilidad de que sea falla de transmision es: "+probTransmision);
         
         
         
    }
    public boolean calcularCoicidencia(ArrayList<String> sintomasBuscados,
                                       ArrayList<String> sintomasReales)
    {
        
      return sintomasReales.containsAll(sintomasBuscados);
    }
    public static void main(String[] args)
    {
        TeoremaBayes t=new TeoremaBayes();
        ArrayList<String> sintomas=new ArrayList<>();
        sintomas.add("Sintoma1");
        sintomas.add("Sintoma2");
        sintomas.add("Sintoma3");
        
        t.consulta("Mazda",sintomas);
        
        System.out.println("");
        System.out.println("");
        System.out.println("");
        
        t.consulta("Ford",sintomas);
        
         System.out.println("");
         System.out.println("");
         System.out.println("");
         
        t.consulta("Chevrolet",sintomas);
        
    }
    public ArrayList<Carro> buscarCarros(String marca)
    {
        ArrayList<Carro> carrosTemp=new ArrayList<>();
        
        for (int i = 0; i <this.carros.size(); i++) 
        {
            Carro carroTemp=this.carros.get(i);
            if(carroTemp.getMarca().equals(marca))
            {
                carrosTemp.add(carroTemp);
            }
        }
        return carrosTemp;
    }
    public Falla generarFalla()
    {
        String[] tipo={"Motor","Sistema Electrico","Transmision"};
        
        String[] sintomas={"Sintoma1","Sintoma2","Sintoma3","Sintoma4","Sintoma5"};
        
        int numeroTipo= (int)(Math.random()*3);
        
        int numerosDeSintomas= (int)(Math.random()*sintomas.length);
        
        Falla falla=new Falla(tipo[numeroTipo]);
        
        for (int i = 0; i <numerosDeSintomas; i++) 
        {
            int numeroSintoma= (int)(Math.random()*5);
            boolean pudo=falla.agregarSintomas(sintomas[numeroSintoma]);
            if(!pudo)
            {
                i--;
            }
            
        }
        
       return falla;
    }
}
