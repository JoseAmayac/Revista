
package tareacarro.excepcion;

/**
 * Mensaje lanzado al momento de frenar bruscamente
 * @author José Luciano Amaya Carrascal
 * @author Hector Fabio Martinez Gomez
 * @version 20170501
 * @since 1.0
 */
public class AutoPatinandoException extends Exception 
{
    /**
     * Constructor de objetos de la clase AutoPatinandoException
     * @param mensaje el mensaje que se muestra al generarse la excepcion
     */
    public AutoPatinandoException(String mensaje)
    {
        super(mensaje);
    }
}
