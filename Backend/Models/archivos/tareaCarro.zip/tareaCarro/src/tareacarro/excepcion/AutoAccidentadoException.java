
package tareacarro.excepcion;

/**
 *Excepcion generado cuando se apaga el vehiculo yendo a más de 60km/h y también cuando se acelera más de la velocidad permitida por el motor
 * @author Hector Fabio Martinez Gomez
 * @author José Luciano Amaya Carrascal
 * @version 20170501
 * @since 1.0
 */
public class AutoAccidentadoException extends Exception
{
    /**
     * constructor de objetos de la clase AutoAccidentadoException
     * @param mensaje el mensaje que se muestra cuando surge la excepcion
     */
    public AutoAccidentadoException(String mensaje)
    {
        super(mensaje);
    } 
}
