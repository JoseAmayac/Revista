
package tareacarro.excepcion;

/**
 *Excepcion lanzada al momento de querer apagar el auto y que este ya se encuentre apagado, o tambien cuando se quiere apagar y el auto este apagado
 * @author José Luciano Amaya Carrascal
 * @author Hector Fabio Martinez Gomez
 * @version 20170501
 * @since 1.0
 */
public class AutoApagadoException extends Exception
{
    
    /**
     * Constructor de objetos de la clase AutoApagadoException
     * @param mensaje el mensaje que se muestra cuando se genera la excepcion
     */
    public AutoApagadoException(String mensaje)
    {
        super(mensaje);
    }  
}
