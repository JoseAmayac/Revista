package tareacarro;

import tareacarro.excepcion.AutoAccidentadoException;
import tareacarro.excepcion.AutoYaFrenadoException;
import tareacarro.excepcion.AutoYaEncendidoException;
import tareacarro.excepcion.AutoApagadoException;
import tareacarro.excepcion.AutoPatinandoException;

/**
 *
 * @author josea
 */
public class Carro 
{
    /**
     * 
     */
    private Llanta llanta;
    
    
    /**
     * 
     */
    private Motor motor;
    
    
    /**
     * 
     */
    private boolean encendido;
    
    /**
     * 
     */
    private boolean frenado;
    
    /**
     * 
     */
    private boolean frenadoBruscamente;
    
    /**
     * 
     */
    private double velocidad;
    
    /**
     * 
     * @param llanta
     * @param motor
     */
    public Carro(Llanta llanta,Motor motor)
    {
        this.llanta=llanta;
        this.motor=motor;
        this.encendido = false;
        this.frenado =true;
        this.frenadoBruscamente=false;
        this.velocidad=0;
    }

    /**
     *
     * @return
     * @throws tareacarro.excepcion.AutoYaEncendidoException
     */
    public boolean encender() throws AutoYaEncendidoException 
    {
        if (!this.encendido)
        {
            this.encendido = true;
        } 
        else
        {
            throw new AutoYaEncendidoException("No se puede encender un auto que ya esta encendido");
        }
        return true;
    }

    /**
     *
     * @return
     * @throws tareacarro.excepcion.AutoApagadoException
     * @throws tareacarro.excepcion.AutoAccidentadoException
     */
    public boolean apagar() throws AutoApagadoException, AutoAccidentadoException 
    {
        if (this.encendido)
        {
            if (this.velocidad<=60)
            {
                this.encendido = false;
            }
            else
            {
               this.velocidad=0;
               this.encendido=false;
               this.frenado=true;
               throw new AutoAccidentadoException("El auto tenia una velocidad mayor a 60km/h");
            }
        } 
        else
        {
            throw new AutoApagadoException("El auto está apagado");
        }
        return true;
    }

    
    /**
     * 
     * @param velocidad
     * @return
     * @throws AutoYaFrenadoException 
     * @throws tareacarro.excepcion.AutoPatinandoException 
     * @throws tareacarro.excepcion.AutoApagadoException 
     */
    public boolean frenar(double velocidad) throws AutoYaFrenadoException, AutoPatinandoException, AutoApagadoException
    {
        if (this.encendido)
        {
           if (!this.frenado)
           {
               if (velocidad>30)
               {
                   if (this.velocidad>llanta.getLimitaPermitido())
                   {
                       this.frenado=true;
                       this.velocidad=0;
                       throw new AutoPatinandoException("velocidad actual mayor a la permitida por las llantas");
                   }
               }
                this.velocidad-=velocidad;
                if (this.velocidad==0)
                {
                   this.frenado = true; 
                }
                else
                {
                    if (this.velocidad<0)
                    {
                        this.frenado=true;
                        this.velocidad=0;
                        throw new AutoPatinandoException("Auto frenado con velocidad mayor a la actual.");
                    }
                }
           }
           else
           {
              throw new AutoYaFrenadoException("El auto está frenado");  
           } 
        }
        else
        {
            throw new AutoApagadoException("El auto esta apagado");
        }
        return true;
    }

    
    /**
     *
     * @return
     */
    public boolean frenarBruscamente() 
    {
        this.frenadoBruscamente = true;
        return frenadoBruscamente;
    }

   
    /**
     * 
     * @param velocidad
     * @return
     * @throws AutoApagadoException 
     */
    public boolean acelerar(double velocidad) throws AutoApagadoException, AutoAccidentadoException
    {
        if (this.encendido)
        {
            if (this.velocidad+velocidad<=motor.getVelocidadMaxima())
            {
                this.velocidad+=velocidad;
                this.frenado = false; 
            }
            else
            {
                this.velocidad=0;
                this.encendido=false;
                this.frenado=true;
                throw new AutoAccidentadoException("El auto se aceleró a una capacidad mayor a la del motor");
            }
        } 
        else
        {
            throw new AutoApagadoException("El auto esta apagado");
        }
        return true;
    }

    public boolean isEncendido()
    {
        return encendido;
    }

    public boolean isFrenado()
    {
        return frenado;
    }

    public double getVelocidad()
    {
        return velocidad;
    }

    public Llanta getLlanta() {
        return llanta;
    }

    public Motor getMotor() {
        return motor;
    }  
}
