/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoestructura2;

/**
 *
 * @author Administrador
 */
public class Carro 
{
    /**
     * 
     */
    private String marca;
    /**
     * 
     */
    private Falla falla;
    
    /**
     * 
     * @param marca 
     */
    public Carro(String marca) 
    {
        this.marca = marca;
        this.falla=null;
    }
    
    /**
     * 
     * @param marca
     * @param falla 
     */
    public Carro(String marca, Falla falla) {
        this.marca = marca;
        this.falla = falla;
    }
    /**
     * 
     * @return 
     */
    public String getMarca() 
    {
        return marca;
    }
    /**
     * 
     * @return 
     */
    public boolean isFalla() 
    {
        return this.falla!=null;
    }
    
    public void generar()
    {
        System.out.println("La marca es:"+getMarca());
        if(isFalla())
        {
            System.out.println("Presento fallas en mi mecanismo");
        }
        else
        {
            System.out.println("No presento fallas en mi mecanismo");
        }
    }

    public Falla getFalla() {
        return falla;
    }
         
    
    
}
